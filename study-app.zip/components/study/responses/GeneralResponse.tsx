import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Info, Stethoscope, Microscope, Copy, Download, ExternalLink, Zap } from "lucide-react"

export default function GeneralResponse() {
  return (
    <div className="space-y-6">
      {/* Response Header */}
      <div className="bg-primary-50 p-4 rounded-lg border border-primary-100 dark:bg-primary-900/20 dark:border-primary-800">
        <h3 className="font-medium text-primary-800 mb-2 dark:text-primary-300">Cystic Fibrosis Pathophysiology</h3>
        <div className="flex flex-wrap gap-2 mb-3">
          <Badge
            variant="secondary"
            className="bg-primary-100 text-primary-700 hover:bg-primary-200 dark:bg-primary-900 dark:text-primary-300"
          >
            First Aid 2025
          </Badge>
          <Badge
            variant="secondary"
            className="bg-primary-100 text-primary-700 hover:bg-primary-200 dark:bg-primary-900 dark:text-primary-300"
          >
            Pathoma 2023
          </Badge>
        </div>
        <p className="text-sm text-gray-600 dark:text-gray-400">
          Showing information from 2 sources. Response generated in 1.2 seconds.
        </p>
      </div>

      {/* Response Content */}
      <div className="space-y-4">
        <div className="key-concept">
          <h4 className="font-medium mb-3 dark:text-white flex items-center">
            <Info className="h-4 w-4 mr-2 text-primary-600 dark:text-primary-400" />
            Key Pathophysiology
          </h4>
          <ul className="space-y-2 text-sm">
            <li className="differential-item">
              <span className="differential-marker">❯</span>
              <span className="dark:text-gray-300">
                <strong>Mutation:</strong> <span className="buzzword">CFTR gene</span> on chromosome 7 (most common:{" "}
                <span className="buzzword">ΔF508</span>) leads to defective chloride channel protein
              </span>
            </li>
            <li className="differential-item">
              <span className="differential-marker">❯</span>
              <span className="dark:text-gray-300">
                <strong>Result:</strong> Defective cAMP-dependent Cl⁻ channel → decreased Cl⁻ secretion and increased
                Na⁺ absorption → dehydrated, thick secretions
              </span>
            </li>
            <li className="differential-item">
              <span className="differential-marker">❯</span>
              <span className="dark:text-gray-300">
                <strong>Inheritance:</strong> <span className="buzzword">Autosomal recessive</span>; 1 in 25 Caucasians
                are carriers
              </span>
            </li>
          </ul>
        </div>

        <div className="p-4 border rounded-lg dark:border-gray-700 dark:bg-gray-800/50">
          <h4 className="font-medium mb-3 dark:text-white flex items-center">
            <Stethoscope className="h-4 w-4 mr-2 text-primary-600 dark:text-primary-400" />
            Clinical Manifestations
          </h4>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700 medical-table">
              <thead>
                <tr>
                  <th>System</th>
                  <th>Manifestation</th>
                  <th>Mechanism</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200 text-sm dark:bg-gray-800 dark:divide-gray-700">
                <tr>
                  <td className="font-medium dark:text-gray-300">Respiratory</td>
                  <td className="dark:text-gray-300">
                    <span className="buzzword">Chronic infections</span>, bronchiectasis
                  </td>
                  <td className="dark:text-gray-300">Thick mucus, impaired mucociliary clearance</td>
                </tr>
                <tr>
                  <td className="font-medium dark:text-gray-300">GI</td>
                  <td className="dark:text-gray-300">
                    <span className="buzzword">Meconium ileus</span>, malabsorption
                  </td>
                  <td className="dark:text-gray-300">Pancreatic enzyme insufficiency, thick intestinal secretions</td>
                </tr>
                <tr>
                  <td className="font-medium dark:text-gray-300">Reproductive</td>
                  <td className="dark:text-gray-300">Male infertility</td>
                  <td className="dark:text-gray-300">
                    <span className="buzzword">Congenital bilateral absence of vas deferens</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="p-4 border rounded-lg dark:border-gray-700 dark:bg-gray-800/50">
          <h4 className="font-medium mb-3 dark:text-white flex items-center">
            <Microscope className="h-4 w-4 mr-2 text-primary-600 dark:text-primary-400" />
            Diagnostic Findings
          </h4>
          <ul className="space-y-2 text-sm">
            <li className="differential-item">
              <span className="differential-marker">❯</span>
              <span className="dark:text-gray-300">
                <strong>Sweat test:</strong> ↑ Cl⁻ concentration (&gt;60 mEq/L) -{" "}
                <span className="buzzword">gold standard</span>
              </span>
            </li>
            <li className="differential-item">
              <span className="differential-marker">❯</span>
              <span className="dark:text-gray-300">
                <strong>Genetic testing:</strong> Identifies CFTR mutations
              </span>
            </li>
            <li className="differential-item">
              <span className="differential-marker">❯</span>
              <span className="dark:text-gray-300">
                <strong>Newborn screening:</strong> ↑ <span className="buzzword">immunoreactive trypsinogen (IRT)</span>
              </span>
            </li>
          </ul>
        </div>
      </div>

      {/* Response Actions */}
      <div className="flex justify-between items-center pt-2">
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="text-xs gap-1 dark:border-gray-700 dark:text-gray-300">
            <Copy className="h-3 w-3" />
            Copy
          </Button>
          <Button variant="outline" size="sm" className="text-xs gap-1 dark:border-gray-700 dark:text-gray-300">
            <Download className="h-3 w-3" />
            Save
          </Button>
          <Button variant="outline" size="sm" className="text-xs gap-1 dark:border-gray-700 dark:text-gray-300">
            <ExternalLink className="h-3 w-3" />
            Expand
          </Button>
        </div>
        <div>
          <Button
            variant="outline"
            size="sm"
            className="text-xs text-accent-600 border-accent-200 hover:bg-accent-50 dark:text-accent-400 dark:border-accent-800 dark:hover:bg-accent-900/20"
          >
            <Zap className="h-3 w-3 mr-1 text-accent-500" />
            Show high-yield facts
          </Button>
        </div>
      </div>
    </div>
  )
}
