"use client"

import { useState, useEffect } from "react"
import { useTheme } from "next-themes"
import Header from "@/components/layout/Header"
import Footer from "@/components/layout/Footer"
import Sidebar from "@/components/layout/Sidebar"
import MainContent from "@/components/layout/MainContent"

export default function StudyApp() {
  const [searchQuery, setSearchQuery] = useState("")
  const [viewMode, setViewMode] = useState<"grid" | "list">("list")
  const [activeTab, setActiveTab] = useState<"search" | "flashcards" | "timer">("search")
  const [mounted, setMounted] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [responseMode, setResponseMode] = useState<"general" | "hy" | "hdt" | "diff">("general")
  const { theme } = useTheme()

  // For theme toggle
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      {/* Header */}
      <Header mobileMenuOpen={mobileMenuOpen} setMobileMenuOpen={setMobileMenuOpen} />

      {/* Main Content */}
      <div className="flex flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 gap-6">
        {/* Sidebar */}
        <Sidebar />

        {/* Main Content Area */}
        <MainContent
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          responseMode={responseMode}
          setResponseMode={setResponseMode}
        />
      </div>

      {/* Footer */}
      <Footer />
    </div>
  )
}
